-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (account_id);


--
-- TOC entry 3340 (class 2606 OID 31606)
-- Name: appointment appointment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT appointment_pkey PRIMARY KEY (appointment_id);


--
-- TOC entry 3304 (class 2606 OID 31374)
-- Name: appointment_type appointment_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment_type
    ADD CONSTRAINT appointment_type_pkey PRIMARY KEY (appointment_type);


--
-- TOC entry 3302 (class 2606 OID 31369)
-- Name: appoitment_status appoitment_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appoitment_status
    ADD CONSTRAINT appoitment_status_pkey PRIMARY KEY (appoitment_status);


--
-- TOC entry 3330 (class 2606 OID 31491)
-- Name: blood_group blood_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blood_group
    ADD CONSTRAINT blood_group_pkey PRIMARY KEY (blood_group);


--
-- TOC entry 3308 (class 2606 OID 31384)
-- Name: city city_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city
    ADD CONSTRAINT city_pkey PRIMARY KEY (city_abbrevation);


--
-- TOC entry 3310 (class 2606 OID 31394)
-- Name: country country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country
    ADD CONSTRAINT country_pkey PRIMARY KEY (country_name);


--
-- TOC entry 3292 (class 2606 OID 31344)
-- Name: education education_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.education
    ADD CONSTRAINT education_pkey PRIMARY KEY (education_name);


--
-- TOC entry 3346 (class 2606 OID 31774)
-- Name: enrollment enrollment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollment
    ADD CONSTRAINT enrollment_pkey PRIMARY KEY (guid);


--
-- TOC entry 3298 (class 2606 OID 31359)
-- Name: experience experience_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experience
    ADD CONSTRAINT experience_pkey PRIMARY KEY (experience);


--
-- TOC entry 3318 (class 2606 OID 31414)
-- Name: gateway gateway_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gateway
    ADD CONSTRAINT gateway_pkey PRIMARY KEY (gateway);


--
-- TOC entry 3314 (class 2606 OID 31404)
-- Name: gender gender_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gender
    ADD CONSTRAINT gender_pkey PRIMARY KEY (gender);


--
-- TOC entry 3316 (class 2606 OID 31409)
-- Name: mode mode_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mode
    ADD CONSTRAINT mode_pkey PRIMARY KEY (mode);


--
-- TOC entry 3338 (class 2606 OID 31581)
-- Name: patient_address patient_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_address
    ADD CONSTRAINT patient_address_pkey PRIMARY KEY (address_id);


--
-- TOC entry 3332 (class 2606 OID 31496)
-- Name: patient patient_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT patient_pkey PRIMARY KEY (pateint_id);


--
-- TOC entry 3342 (class 2606 OID 31637)
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (payment_id);


--
-- TOC entry 3344 (class 2606 OID 31642)
-- Name: payment_status payment_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_status
    ADD CONSTRAINT payment_status_pkey PRIMARY KEY (payment_status);


--
-- TOC entry 3312 (class 2606 OID 31399)
-- Name: prefix prefix_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prefix
    ADD CONSTRAINT prefix_pkey PRIMARY KEY (prefix);


--
-- TOC entry 3336 (class 2606 OID 31551)
-- Name: provider_clinic_location provider_clinic_location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_clinic_location
    ADD CONSTRAINT provider_clinic_location_pkey PRIMARY KEY (location_id);


--
-- TOC entry 3334 (class 2606 OID 31521)
-- Name: provider_clinic provider_clinic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_clinic
    ADD CONSTRAINT provider_clinic_pkey PRIMARY KEY (provider_clinic_id);


--
-- TOC entry 3326 (class 2606 OID 31464)
-- Name: provider_education provider_education_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_education
    ADD CONSTRAINT provider_education_pkey PRIMARY KEY (provider_education_id);


--
-- TOC entry 3324 (class 2606 OID 31449)
-- Name: provider provider_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider
    ADD CONSTRAINT provider_pkey PRIMARY KEY (provider_id);


--
-- TOC entry 3328 (class 2606 OID 31476)
-- Name: provider_specialization provider_specialization_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_specialization
    ADD CONSTRAINT provider_specialization_pkey PRIMARY KEY (provider_specialization_id);


--
-- TOC entry 3294 (class 2606 OID 31349)
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (role);


--
-- TOC entry 3300 (class 2606 OID 31364)
-- Name: slot slot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.slot
    ADD CONSTRAINT slot_pkey PRIMARY KEY (slot_id);


--
-- TOC entry 3296 (class 2606 OID 31354)
-- Name: specialization specialization_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specialization
    ADD CONSTRAINT specialization_pkey PRIMARY KEY (speciality);


--
-- TOC entry 3306 (class 2606 OID 31379)
-- Name: state state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.state
    ADD CONSTRAINT state_pkey PRIMARY KEY (state_abbrevation);


--
-- TOC entry 3322 (class 2606 OID 31424)
-- Name: users user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- TOC entry 3348 (class 2606 OID 31435)
-- Name: users account_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT account_id FOREIGN KEY (account_id) REFERENCES public.account(account_id) NOT VALID;


--
-- TOC entry 3370 (class 2606 OID 31628)
-- Name: appointment appointment_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT appointment_type FOREIGN KEY (appointment_type) REFERENCES public.appointment_type(appointment_type) NOT VALID;


--
-- TOC entry 3371 (class 2606 OID 31623)
-- Name: appointment appoitment_status; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT appoitment_status FOREIGN KEY (appointment_status) REFERENCES public.appoitment_status(appoitment_status) NOT VALID;


--
-- TOC entry 3357 (class 2606 OID 31512)
-- Name: patient blood_group; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT blood_group FOREIGN KEY (blood_group) REFERENCES public.blood_group(blood_group) NOT VALID;


--
-- TOC entry 3361 (class 2606 OID 31552)
-- Name: provider_clinic_location city_abbrevation; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_clinic_location
    ADD CONSTRAINT city_abbrevation FOREIGN KEY (city_abbrevation) REFERENCES public.city(city_abbrevation);


--
-- TOC entry 3366 (class 2606 OID 31582)
-- Name: patient_address city_abbrevation; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_address
    ADD CONSTRAINT city_abbrevation FOREIGN KEY (city_abbrevation) REFERENCES public.city(city_abbrevation);


--
-- TOC entry 3362 (class 2606 OID 31562)
-- Name: provider_clinic_location country_name; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_clinic_location
    ADD CONSTRAINT country_name FOREIGN KEY (country_name) REFERENCES public.country(country_name) NOT VALID;


--
-- TOC entry 3367 (class 2606 OID 31592)
-- Name: patient_address country_name; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_address
    ADD CONSTRAINT country_name FOREIGN KEY (country_name) REFERENCES public.country(country_name) NOT VALID;


--
-- TOC entry 3352 (class 2606 OID 31455)
-- Name: provider experience; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider
    ADD CONSTRAINT experience FOREIGN KEY (experience) REFERENCES public.experience(experience) NOT VALID;


--
-- TOC entry 3376 (class 2606 OID 31653)
-- Name: payment gateway; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT gateway FOREIGN KEY (gateway) REFERENCES public.gateway(gateway) NOT VALID;


--
-- TOC entry 3349 (class 2606 OID 31430)
-- Name: users gender; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT gender FOREIGN KEY (gender) REFERENCES public.gender(gender) NOT VALID;


--
-- TOC entry 3358 (class 2606 OID 31507)
-- Name: patient gender; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT gender FOREIGN KEY (gender) REFERENCES public.gender(gender) NOT VALID;


--
-- TOC entry 3377 (class 2606 OID 31648)
-- Name: payment mode; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT mode FOREIGN KEY (mode) REFERENCES public.mode(mode) NOT VALID;


--
-- TOC entry 3368 (class 2606 OID 31597)
-- Name: patient_address patient_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_address
    ADD CONSTRAINT patient_id FOREIGN KEY (patient_id) REFERENCES public.patient(pateint_id) NOT VALID;


--
-- TOC entry 3372 (class 2606 OID 31613)
-- Name: appointment patient_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT patient_id FOREIGN KEY (patient_id) REFERENCES public.patient(pateint_id) NOT VALID;


--
-- TOC entry 3379 (class 2606 OID 31775)
-- Name: enrollment patient_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollment
    ADD CONSTRAINT patient_id FOREIGN KEY (patient_id) REFERENCES public.patient(pateint_id);


--
-- TOC entry 3373 (class 2606 OID 31658)
-- Name: appointment payment_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT payment_id FOREIGN KEY (payment_id) REFERENCES public.payment(payment_id) NOT VALID;


--
-- TOC entry 3378 (class 2606 OID 31643)
-- Name: payment payment_status; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_status FOREIGN KEY (payment_status) REFERENCES public.payment_status(payment_status) NOT VALID;


--
-- TOC entry 3350 (class 2606 OID 31425)
-- Name: users prefix; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT prefix FOREIGN KEY (prefix) REFERENCES public.prefix(prefix);


--
-- TOC entry 3363 (class 2606 OID 31572)
-- Name: provider_clinic_location provider_clinic_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_clinic_location
    ADD CONSTRAINT provider_clinic_id FOREIGN KEY (provider_clinic_id) REFERENCES public.provider_clinic(provider_clinic_id) NOT VALID;


--
-- TOC entry 3354 (class 2606 OID 31465)
-- Name: provider_education provider_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_education
    ADD CONSTRAINT provider_id FOREIGN KEY (provider_id) REFERENCES public.provider(provider_id);


--
-- TOC entry 3355 (class 2606 OID 31482)
-- Name: provider_specialization provider_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_specialization
    ADD CONSTRAINT provider_id FOREIGN KEY (provider_id) REFERENCES public.provider(provider_id) NOT VALID;


--
-- TOC entry 3359 (class 2606 OID 31497)
-- Name: patient provider_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT provider_id FOREIGN KEY (provider_id) REFERENCES public.provider(provider_id);


--
-- TOC entry 3364 (class 2606 OID 31567)
-- Name: provider_clinic_location provider_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_clinic_location
    ADD CONSTRAINT provider_id FOREIGN KEY (provider_id) REFERENCES public.provider(provider_id) NOT VALID;


--
-- TOC entry 3374 (class 2606 OID 31607)
-- Name: appointment provider_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT provider_id FOREIGN KEY (provider_id) REFERENCES public.provider(provider_id);


--
-- TOC entry 3351 (class 2606 OID 31440)
-- Name: users role; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT role FOREIGN KEY (role) REFERENCES public.role(role) NOT VALID;


--
-- TOC entry 3375 (class 2606 OID 31618)
-- Name: appointment slot_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT slot_id FOREIGN KEY (slot_id) REFERENCES public.slot(slot_id) NOT VALID;


--
-- TOC entry 3356 (class 2606 OID 31477)
-- Name: provider_specialization speciality; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_specialization
    ADD CONSTRAINT speciality FOREIGN KEY (speciality) REFERENCES public.specialization(speciality);


--
-- TOC entry 3347 (class 2606 OID 31385)
-- Name: city state_abbrevation; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city
    ADD CONSTRAINT state_abbrevation FOREIGN KEY (state_abbrevation) REFERENCES public.state(state_abbrevation);


--
-- TOC entry 3365 (class 2606 OID 31557)
-- Name: provider_clinic_location state_abbrevation; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_clinic_location
    ADD CONSTRAINT state_abbrevation FOREIGN KEY (state_abbrevation) REFERENCES public.state(state_abbrevation) NOT VALID;


--
-- TOC entry 3369 (class 2606 OID 31587)
-- Name: patient_address state_abbrevation; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient_address
    ADD CONSTRAINT state_abbrevation FOREIGN KEY (state_abbrevation) REFERENCES public.state(state_abbrevation) NOT VALID;


--
-- TOC entry 3353 (class 2606 OID 31450)
-- Name: provider user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider
    ADD CONSTRAINT user_id FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- TOC entry 3360 (class 2606 OID 31502)
-- Name: patient user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT user_id FOREIGN KEY (user_id) REFERENCES public.users(user_id) NOT VALID;


-- Completed on 2023-04-06 14:43:55

--
-- PostgreSQL database dump complete
--

