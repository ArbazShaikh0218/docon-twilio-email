-- Name: account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account (
    account_id bigint NOT NULL,
    username character varying(50),
    password character varying(50)
);


-- Name: enrollment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.enrollment (
    guid uuid NOT NULL,
    expiry character varying(10),
    pateint_id bigint
);


-- Name: appointment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointment (
    appointment_id bigint NOT NULL,
    provider_id bigint,
    patient_id bigint,
    slot_id bigint,
    appointment_status character varying(20),
    appointment_type character varying(30),
    payment_id bigint
);

-- Name: appointment_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointment_type (
    appointment_type character varying(30) NOT NULL
);


-- Name: appoitment_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appoitment_status (
    appoitment_status character varying(15) NOT NULL
);

-- Name: blood_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blood_group (
    blood_group character varying(20) NOT NULL
);

-- Name: city; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.city (
    city_abbrevation character varying(10) NOT NULL,
    city_name character varying(30),
    state_abbrevation character varying(10)
);


-- Name: country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.country (
    country_name character varying(30) NOT NULL
);

-- Name: education; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.education (
    education_name character varying(10) NOT NULL
);

-- Name: experience; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.experience (
    experience character varying(10) NOT NULL
);


-- Name: gateway; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gateway (
    gateway character varying(15) NOT NULL
);

-- Name: gender; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gender (
    gender character varying(15) NOT NULL
);

-- Name: mode; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mode (
    mode character varying(15) NOT NULL
);

-- Name: patient; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient (
    pateint_id bigint NOT NULL,
    provider_id bigint,
    user_id bigint,
    gender character varying(15),
    blood_group character varying(15),
    height bigint,
    weight bigint
);

-- Name: patient_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient_address (
    address_id bigint NOT NULL,
    address_line_1 character varying(50),
    address_line_2 character varying(50),
    city_abbrevation character varying(10),
    state_abbrevation character varying(10),
    country_name character varying(50),
    zipcode character varying(10),
    patient_id bigint
);

-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment (
    payment_id bigint NOT NULL,
    amount double precision,
    payment_status character varying(20),
    mode character varying(20),
    gateway character varying(30),
    transaction_number character varying(20)
);

-- Name: payment_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_status (
    payment_status character varying(20) NOT NULL
);


-- Name: prefix; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prefix (
    prefix character varying(10) NOT NULL,
    abbrevation character varying(10)
);

-- Name: provider; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provider (
    provider_id bigint NOT NULL,
    provider_image character varying(255),
    user_id bigint,
    mci_registration_number bigint,
    experience character varying(10)
);

-- Name: provider_clinic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provider_clinic (
    provider_clinic_id bigint NOT NULL,
    clinic_name character varying(50)
);

-- Name: provider_clinic_location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provider_clinic_location (
    location_id bigint NOT NULL,
    address_line_1 character varying(50),
    address_line_2 character varying(50),
    city_abbrevation character varying(10),
    state_abbrevation character varying(10),
    country_name character varying(50),
    provider_id bigint,
    provider_clinic_id bigint
);

-- Name: provider_education; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provider_education (
    provider_education_id bigint NOT NULL,
    provider_id bigint
);

-- Name: provider_specialization; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provider_specialization (
    provider_specialization_id bigint NOT NULL,
    speciality character varying,
    provider_id bigint
);

-- Name: role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role (
    role character varying(20) NOT NULL
);

-- Name: slot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.slot (
    slot_id bigint NOT NULL,
    start_time time with time zone,
    end_time time with time zone
);

-- Name: specialization; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.specialization (
    speciality character varying(30) NOT NULL
);

-- Name: state; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.state (
    state_abbrevation character varying(10) NOT NULL,
    state_name character varying(30)
);

-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id bigint NOT NULL,
    prefix character varying(10),
    first_name character varying(50),
    last_name character varying(50),
    dob date,
    gender character varying(15),
    account_id bigint,
    role character varying(15)
);